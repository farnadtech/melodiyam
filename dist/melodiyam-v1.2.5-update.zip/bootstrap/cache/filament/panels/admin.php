<?php return array (
  'livewireComponents' => 
  array (
    'App\\Filament\\Resources\\AdvertisementResource\\Pages\\CreateAdvertisement' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\CreateAdvertisement',
    'App\\Filament\\Resources\\AdvertisementResource\\Pages\\EditAdvertisement' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\EditAdvertisement',
    'App\\Filament\\Resources\\AdvertisementResource\\Pages\\ListAdvertisements' => 'App\\Filament\\Resources\\AdvertisementResource\\Pages\\ListAdvertisements',
    'App\\Filament\\Resources\\AlbumResource\\Pages\\CreateAlbum' => 'App\\Filament\\Resources\\AlbumResource\\Pages\\CreateAlbum',
    'App\\Filament\\Resources\\AlbumResource\\Pages\\EditAlbum' => 'App\\Filament\\Resources\\AlbumResource\\Pages\\EditAlbum',
    'App\\Filament\\Resources\\AlbumResource\\Pages\\ListAlbums' => 'App\\Filament\\Resources\\AlbumResource\\Pages\\ListAlbums',
    'App\\Filament\\Resources\\ArtistApplicationResource\\Pages\\EditArtistApplication' => 'App\\Filament\\Resources\\ArtistApplicationResource\\Pages\\EditArtistApplication',
    'App\\Filament\\Resources\\ArtistApplicationResource\\Pages\\ListArtistApplications' => 'App\\Filament\\Resources\\ArtistApplicationResource\\Pages\\ListArtistApplications',
    'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\CreateArtistEarning' => 'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\CreateArtistEarning',
    'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\EditArtistEarning' => 'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\EditArtistEarning',
    'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\ListArtistEarnings' => 'App\\Filament\\Resources\\ArtistEarningResource\\Pages\\ListArtistEarnings',
    'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\CreateArtistPlan' => 'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\CreateArtistPlan',
    'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\EditArtistPlan' => 'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\EditArtistPlan',
    'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\ListArtistPlans' => 'App\\Filament\\Resources\\ArtistPlanResource\\Pages\\ListArtistPlans',
    'App\\Filament\\Resources\\ArtistResource\\Pages\\CreateArtist' => 'App\\Filament\\Resources\\ArtistResource\\Pages\\CreateArtist',
    'App\\Filament\\Resources\\ArtistResource\\Pages\\EditArtist' => 'App\\Filament\\Resources\\ArtistResource\\Pages\\EditArtist',
    'App\\Filament\\Resources\\ArtistResource\\Pages\\ListArtists' => 'App\\Filament\\Resources\\ArtistResource\\Pages\\ListArtists',
    'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\CreateArtistSubscription' => 'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\CreateArtistSubscription',
    'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\EditArtistSubscription' => 'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\EditArtistSubscription',
    'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\ListArtistSubscriptions' => 'App\\Filament\\Resources\\ArtistSubscriptionResource\\Pages\\ListArtistSubscriptions',
    'App\\Filament\\Resources\\CommissionRules\\Pages\\CreateCommissionRule' => 'App\\Filament\\Resources\\CommissionRules\\Pages\\CreateCommissionRule',
    'App\\Filament\\Resources\\CommissionRules\\Pages\\EditCommissionRule' => 'App\\Filament\\Resources\\CommissionRules\\Pages\\EditCommissionRule',
    'App\\Filament\\Resources\\CommissionRules\\Pages\\ListCommissionRules' => 'App\\Filament\\Resources\\CommissionRules\\Pages\\ListCommissionRules',
    'App\\Filament\\Resources\\Coupons\\Pages\\CreateCoupon' => 'App\\Filament\\Resources\\Coupons\\Pages\\CreateCoupon',
    'App\\Filament\\Resources\\Coupons\\Pages\\EditCoupon' => 'App\\Filament\\Resources\\Coupons\\Pages\\EditCoupon',
    'App\\Filament\\Resources\\Coupons\\Pages\\ListCoupons' => 'App\\Filament\\Resources\\Coupons\\Pages\\ListCoupons',
    'App\\Filament\\Resources\\GenreResource\\Pages\\CreateGenre' => 'App\\Filament\\Resources\\GenreResource\\Pages\\CreateGenre',
    'App\\Filament\\Resources\\GenreResource\\Pages\\EditGenre' => 'App\\Filament\\Resources\\GenreResource\\Pages\\EditGenre',
    'App\\Filament\\Resources\\GenreResource\\Pages\\ListGenres' => 'App\\Filament\\Resources\\GenreResource\\Pages\\ListGenres',
    'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\CreateHomepageSection' => 'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\CreateHomepageSection',
    'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\EditHomepageSection' => 'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\EditHomepageSection',
    'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\ListHomepageSections' => 'App\\Filament\\Resources\\HomepageSectionResource\\Pages\\ListHomepageSections',
    'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'App\\Filament\\Resources\\PageResource\\Pages\\EditPage' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'App\\Filament\\Resources\\PageResource\\Pages\\ListPages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'App\\Filament\\Resources\\Payments\\Pages\\CreatePayment' => 'App\\Filament\\Resources\\Payments\\Pages\\CreatePayment',
    'App\\Filament\\Resources\\Payments\\Pages\\EditPayment' => 'App\\Filament\\Resources\\Payments\\Pages\\EditPayment',
    'App\\Filament\\Resources\\Payments\\Pages\\ListPayments' => 'App\\Filament\\Resources\\Payments\\Pages\\ListPayments',
    'App\\Filament\\Resources\\PendingTrackResource\\Pages\\ManagePendingTracks' => 'App\\Filament\\Resources\\PendingTrackResource\\Pages\\ManagePendingTracks',
    'App\\Filament\\Resources\\PlanResource\\Pages\\CreatePlan' => 'App\\Filament\\Resources\\PlanResource\\Pages\\CreatePlan',
    'App\\Filament\\Resources\\PlanResource\\Pages\\EditPlan' => 'App\\Filament\\Resources\\PlanResource\\Pages\\EditPlan',
    'App\\Filament\\Resources\\PlanResource\\Pages\\ListPlans' => 'App\\Filament\\Resources\\PlanResource\\Pages\\ListPlans',
    'App\\Filament\\Resources\\PlaylistResource\\Pages\\CreatePlaylist' => 'App\\Filament\\Resources\\PlaylistResource\\Pages\\CreatePlaylist',
    'App\\Filament\\Resources\\PlaylistResource\\Pages\\EditPlaylist' => 'App\\Filament\\Resources\\PlaylistResource\\Pages\\EditPlaylist',
    'App\\Filament\\Resources\\PlaylistResource\\Pages\\ListPlaylists' => 'App\\Filament\\Resources\\PlaylistResource\\Pages\\ListPlaylists',
    'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\CreatePodcastEpisode' => 'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\CreatePodcastEpisode',
    'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\EditPodcastEpisode' => 'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\EditPodcastEpisode',
    'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\ListPodcastEpisodes' => 'App\\Filament\\Resources\\PodcastEpisodeResource\\Pages\\ListPodcastEpisodes',
    'App\\Filament\\Resources\\PodcastResource\\Pages\\CreatePodcast' => 'App\\Filament\\Resources\\PodcastResource\\Pages\\CreatePodcast',
    'App\\Filament\\Resources\\PodcastResource\\Pages\\EditPodcast' => 'App\\Filament\\Resources\\PodcastResource\\Pages\\EditPodcast',
    'App\\Filament\\Resources\\PodcastResource\\Pages\\ListPodcasts' => 'App\\Filament\\Resources\\PodcastResource\\Pages\\ListPodcasts',
    'App\\Filament\\Resources\\ReportResource\\Pages\\EditReport' => 'App\\Filament\\Resources\\ReportResource\\Pages\\EditReport',
    'App\\Filament\\Resources\\ReportResource\\Pages\\ListReports' => 'App\\Filament\\Resources\\ReportResource\\Pages\\ListReports',
    'App\\Filament\\Resources\\Reposts\\Pages\\ManageReposts' => 'App\\Filament\\Resources\\Reposts\\Pages\\ManageReposts',
    'App\\Filament\\Resources\\TrackResource\\Pages\\CreateTrack' => 'App\\Filament\\Resources\\TrackResource\\Pages\\CreateTrack',
    'App\\Filament\\Resources\\TrackResource\\Pages\\EditTrack' => 'App\\Filament\\Resources\\TrackResource\\Pages\\EditTrack',
    'App\\Filament\\Resources\\TrackResource\\Pages\\ListTracks' => 'App\\Filament\\Resources\\TrackResource\\Pages\\ListTracks',
    'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'App\\Filament\\Resources\\UserResource\\Pages\\EditUser' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'App\\Filament\\Resources\\WalletTransactionResource\\Pages\\ListWalletTransactions' => 'App\\Filament\\Resources\\WalletTransactionResource\\Pages\\ListWalletTransactions',
    'Filament\\Pages\\Dashboard' => 'Filament\\Pages\\Dashboard',
    'App\\Filament\\Pages\\Settings' => 'App\\Filament\\Pages\\Settings',
    'App\\Filament\\Pages\\SystemUpdate' => 'App\\Filament\\Pages\\SystemUpdate',
    'App\\Filament\\Pages\\Reports' => 'App\\Filament\\Pages\\Reports',
    'App\\Filament\\Pages\\ArtistApplicationSettings' => 'App\\Filament\\Pages\\ArtistApplicationSettings',
    'App\\Filament\\Pages\\NotificationSettings' => 'App\\Filament\\Pages\\NotificationSettings',
    'App\\Filament\\Pages\\SmartPlaylistSettings' => 'App\\Filament\\Pages\\SmartPlaylistSettings',
    'App\\Filament\\Widgets\\RecentTracksTable' => 'App\\Filament\\Widgets\\RecentTracksTable',
    'App\\Filament\\Widgets\\RecentUsersTable' => 'App\\Filament\\Widgets\\RecentUsersTable',
    'App\\Filament\\Widgets\\StatsOverview' => 'App\\Filament\\Widgets\\StatsOverview',
    'App\\Filament\\Widgets\\TopArtistsTable' => 'App\\Filament\\Widgets\\TopArtistsTable',
    'Filament\\Livewire\\DatabaseNotifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'Filament\\Auth\\Pages\\EditProfile' => 'Filament\\Auth\\Pages\\EditProfile',
    'Filament\\Livewire\\GlobalSearch' => 'Filament\\Livewire\\GlobalSearch',
    'Filament\\Livewire\\Notifications' => 'Filament\\Livewire\\Notifications',
    'Filament\\Livewire\\Sidebar' => 'Filament\\Livewire\\Sidebar',
    'Filament\\Livewire\\SimpleUserMenu' => 'Filament\\Livewire\\SimpleUserMenu',
    'Filament\\Livewire\\Topbar' => 'Filament\\Livewire\\Topbar',
    'Filament\\Auth\\Pages\\Login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
    1 => 'App\\Filament\\Pages\\Settings',
    2 => 'App\\Filament\\Pages\\SystemUpdate',
    3 => 'App\\Filament\\Pages\\Reports',
    4 => 'App\\Filament\\Pages\\ArtistApplicationSettings',
    5 => 'App\\Filament\\Pages\\NotificationSettings',
    6 => 'App\\Filament\\Pages\\SmartPlaylistSettings',
  ),
  'pageConfigurations' => 
  array (
  ),
  'pageDirectories' => 
  array (
  ),
  'pageNamespaces' => 
  array (
  ),
  'resources' => 
  array (
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\AdvertisementResource.php' => 'App\\Filament\\Resources\\AdvertisementResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\AlbumResource.php' => 'App\\Filament\\Resources\\AlbumResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ArtistApplicationResource.php' => 'App\\Filament\\Resources\\ArtistApplicationResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ArtistEarningResource.php' => 'App\\Filament\\Resources\\ArtistEarningResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ArtistPlanResource.php' => 'App\\Filament\\Resources\\ArtistPlanResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ArtistResource.php' => 'App\\Filament\\Resources\\ArtistResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ArtistSubscriptionResource.php' => 'App\\Filament\\Resources\\ArtistSubscriptionResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\CommissionRules\\CommissionRuleResource.php' => 'App\\Filament\\Resources\\CommissionRules\\CommissionRuleResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\Coupons\\CouponResource.php' => 'App\\Filament\\Resources\\Coupons\\CouponResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\GenreResource.php' => 'App\\Filament\\Resources\\GenreResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\HomepageSectionResource.php' => 'App\\Filament\\Resources\\HomepageSectionResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\Payments\\PaymentResource.php' => 'App\\Filament\\Resources\\Payments\\PaymentResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PendingTrackResource.php' => 'App\\Filament\\Resources\\PendingTrackResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PlanResource.php' => 'App\\Filament\\Resources\\PlanResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PlaylistResource.php' => 'App\\Filament\\Resources\\PlaylistResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PodcastEpisodeResource.php' => 'App\\Filament\\Resources\\PodcastEpisodeResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\PodcastResource.php' => 'App\\Filament\\Resources\\PodcastResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\ReportResource.php' => 'App\\Filament\\Resources\\ReportResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\Reposts\\RepostResource.php' => 'App\\Filament\\Resources\\Reposts\\RepostResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\TrackResource.php' => 'App\\Filament\\Resources\\TrackResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Resources\\WalletTransactionResource.php' => 'App\\Filament\\Resources\\WalletTransactionResource',
  ),
  'resourceConfigurations' => 
  array (
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\melodiyam\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Widgets\\RecentTracksTable.php' => 'App\\Filament\\Widgets\\RecentTracksTable',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Widgets\\RecentUsersTable.php' => 'App\\Filament\\Widgets\\RecentUsersTable',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    'C:\\xampp\\htdocs\\melodiyam\\app\\Filament\\Widgets\\TopArtistsTable.php' => 'App\\Filament\\Widgets\\TopArtistsTable',
    0 => 'App\\Filament\\Widgets\\StatsOverview',
    1 => 'App\\Filament\\Widgets\\RecentTracksTable',
    2 => 'App\\Filament\\Widgets\\TopArtistsTable',
    3 => 'App\\Filament\\Widgets\\RecentUsersTable',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\melodiyam\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);