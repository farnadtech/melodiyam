<x-filament-panels::page>

    {{-- ===== PROGRESS POPUP (Alpine) ===== --}}
    <div x-data="updateProgress()" x-init="init()" wire:ignore>
        <div
            x-show="visible"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            class="fixed inset-0 z-[9999] flex items-center justify-center bg-gray-900/70 backdrop-blur-sm px-4"
            style="display:none"
        >
            <div class="w-full max-w-sm rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 shadow-2xl p-6 space-y-5">

                {{-- عنوان --}}
                <div class="flex items-center gap-3">
                    <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary-50 dark:bg-primary-400/10">
                        <x-filament::icon icon="heroicon-o-arrow-path" class="h-5 w-5 text-primary-600 dark:text-primary-400 animate-spin" />
                    </div>
                    <div>
                        <p class="text-sm font-bold text-gray-900 dark:text-white">در حال نصب بروزرسانی</p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">صفحه را نبندید</p>
                    </div>
                </div>

                {{-- مراحل --}}
                <div class="space-y-2.5">
                    <template x-for="(label, i) in steps" :key="i">
                        <div class="flex items-center gap-2.5">
                            <div class="flex h-6 w-6 shrink-0 items-center justify-center rounded-full transition-colors duration-300"
                                :class="{
                                    'bg-success-100 dark:bg-success-400/10': currentStep > i+1,
                                    'bg-primary-100 dark:bg-primary-400/10 ring-2 ring-primary-400': currentStep === i+1,
                                    'bg-gray-100 dark:bg-gray-800': currentStep < i+1
                                }">
                                <svg x-show="currentStep > i+1" class="h-3.5 w-3.5 text-success-600 dark:text-success-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
                                <div x-show="currentStep === i+1" class="h-2 w-2 rounded-full bg-primary-500 animate-pulse"></div>
                                <div x-show="currentStep < i+1" class="h-1.5 w-1.5 rounded-full bg-gray-300 dark:bg-gray-600"></div>
                            </div>
                            <span class="text-xs transition-colors duration-300"
                                :class="{
                                    'text-success-600 dark:text-success-400 font-medium': currentStep > i+1,
                                    'text-primary-700 dark:text-primary-300 font-semibold': currentStep === i+1,
                                    'text-gray-400 dark:text-gray-500': currentStep < i+1
                                }"
                                x-text="label">
                            </span>
                        </div>
                    </template>
                </div>

                {{-- Progress bar --}}
                <div class="space-y-1.5">
                    <div class="flex justify-between text-xs text-gray-400">
                        <span x-text="progressLabel"></span>
                        <span x-text="progressPercent + '%'"></span>
                    </div>
                    <div class="h-2 w-full rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
                        <div class="h-full rounded-full bg-primary-500 transition-all duration-700 ease-out"
                            :style="'width:' + progressPercent + '%'">
                        </div>
                    </div>
                </div>

                <p class="text-center text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-400/10 rounded-lg py-2 px-3 border border-amber-200 dark:border-amber-400/20">
                    ⚠️ اتصال اینترنت را قطع نکنید
                </p>
            </div>
        </div>
    </div>

    {{-- ===== محتوای صفحه ===== --}}
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        {{-- بروزرسانی خودکار --}}
        <x-filament::section>
            <x-slot name="heading">
                <div class="flex items-center gap-2">
                    <x-filament::icon icon="heroicon-o-arrow-path" class="h-5 w-5 text-primary-500" />
                    <span>بروزرسانی خودکار</span>
                </div>
            </x-slot>

            <div class="space-y-4">

                {{-- نسخه‌ها --}}
                <div class="grid grid-cols-2 gap-3">
                    <div class="rounded-xl border border-gray-100 dark:border-white/10 bg-gray-50 dark:bg-white/5 p-3 text-center">
                        <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">نسخه فعلی</p>
                        <p class="font-mono text-base font-bold text-gray-900 dark:text-white">{{ $currentVersion }}</p>
                    </div>
                    <div class="rounded-xl border border-gray-100 dark:border-white/10 bg-gray-50 dark:bg-white/5 p-3 text-center">
                        <p class="text-xs text-gray-500 dark:text-gray-400 mb-1">آخرین نسخه</p>
                        <p class="font-mono text-base font-bold {{ $hasUpdate ? 'text-primary-600 dark:text-primary-400' : 'text-gray-900 dark:text-white' }}">{{ $serverVersion }}</p>
                    </div>
                </div>

                @if($hasUpdate)
                    <div class="rounded-xl border border-primary-200 dark:border-primary-400/20 bg-primary-50 dark:bg-primary-400/10 p-3">
                        <p class="text-xs text-primary-700 dark:text-primary-300 mb-3">
                            نسخه جدید در دسترس است. سیستم به صورت خودکار بروزرسانی خواهد شد.
                        </p>
                        <x-filament::button
                            wire:click="runUpdate"
                            color="primary"
                            icon="heroicon-o-arrow-down-circle"
                            class="w-full"
                            wire:loading.attr="disabled"
                            x-on:click="visible=true; currentStep=1; simulateProgress()"
                        >
                            <span wire:loading.remove wire:target="runUpdate">نصب نسخه {{ $serverVersion }}</span>
                            <span wire:loading wire:target="runUpdate">در حال پردازش...</span>
                        </x-filament::button>
                    </div>
                @else
                    <div class="flex items-center gap-2.5 rounded-xl border border-success-200 dark:border-success-400/20 bg-success-50 dark:bg-success-400/10 p-3">
                        <x-filament::icon icon="heroicon-o-check-circle" class="h-5 w-5 text-success-600 dark:text-success-400 shrink-0" />
                        <span class="text-sm font-medium text-success-700 dark:text-success-400">شما از آخرین نسخه استفاده می‌کنید</span>
                    </div>

                    <x-filament::button
                        wire:click="checkUpdate"
                        color="gray"
                        variant="outlined"
                        icon="heroicon-o-magnifying-glass"
                        class="w-full"
                        wire:loading.attr="disabled"
                    >
                        <span wire:loading.remove wire:target="checkUpdate">بررسی مجدد</span>
                        <span wire:loading wire:target="checkUpdate">در حال بررسی...</span>
                    </x-filament::button>
                @endif

                @if($errorDebug)
                    <div class="rounded-lg border border-danger-200 dark:border-danger-400/20 bg-danger-50 dark:bg-danger-400/10 p-3">
                        <p class="text-xs font-mono text-danger-600 dark:text-danger-400 break-all leading-relaxed">
                            خطا: {{ $errorDebug }}
                        </p>
                    </div>
                @endif

            </div>
        </x-filament::section>

        {{-- آپدیت دستی --}}
        <x-filament::section>
            <x-slot name="heading">
                <div class="flex items-center gap-2">
                    <x-filament::icon icon="heroicon-o-arrow-up-tray" class="h-5 w-5 text-gray-500" />
                    <span>آپدیت دستی</span>
                </div>
            </x-slot>

            <form
                wire:submit.prevent="uploadManualUpdate"
                class="space-y-4"
                x-on:submit="visible=true; currentStep=1; simulateProgress()"
            >
                <p class="text-xs text-gray-500 dark:text-gray-400 leading-6">
                    اگر آپدیت خودکار انجام نمی‌شود، فایل ZIP پکیج آپدیت را اینجا آپلود کنید.
                </p>

                {{ $this->form }}

                <x-filament::button
                    type="submit"
                    color="gray"
                    icon="heroicon-o-cloud-arrow-up"
                    class="w-full"
                    wire:loading.attr="disabled"
                >
                    <span wire:loading.remove wire:target="uploadManualUpdate">نصب پکیج آپلود شده</span>
                    <span wire:loading wire:target="uploadManualUpdate">در حال نصب...</span>
                </x-filament::button>
            </form>
        </x-filament::section>

        {{-- Changelog --}}
        <div class="md:col-span-2">
            <x-filament::section collapsible collapsed>
                <x-slot name="heading">
                    <div class="flex items-center gap-2">
                        <x-filament::icon icon="heroicon-o-list-bullet" class="h-5 w-5 text-primary-500" />
                        <span>لیست تغییرات (Changelog)</span>
                    </div>
                </x-slot>

                @if($changelog)
                    <div class="rounded-xl border border-gray-100 dark:border-white/5 bg-gray-50 dark:bg-white/2 p-5 text-sm text-gray-600 dark:text-gray-300 leading-8">
                        {!! nl2br(e($changelog)) !!}
                    </div>
                @else
                    <div class="py-8 text-center text-sm italic text-gray-400 dark:text-gray-600">
                        توضیحاتی برای نمایش وجود ندارد.
                    </div>
                @endif
            </x-filament::section>
        </div>

    </div>

    {{-- Alpine Logic --}}
    <script>
        function updateProgress() {
            return {
                visible: false,
                currentStep: 0,
                steps: [
                    'دریافت اطلاعات از سرور',
                    'دانلود فایل بروزرسانی',
                    'پشتیبان‌گیری و جایگزینی فایل‌ها',
                    'اجرای migrations و پاکسازی کش',
                ],
                get progressPercent() {
                    if (this.currentStep === 0) return 0;
                    return Math.min(Math.round((this.currentStep / this.steps.length) * 100), 100);
                },
                get progressLabel() {
                    if (this.currentStep === 0) return 'آماده';
                    if (this.currentStep > this.steps.length) return 'تکمیل شد ✓';
                    return this.steps[this.currentStep - 1];
                },
                init() {
                    window.addEventListener('update-step', (e) => {
                        const step = Array.isArray(e.detail) ? e.detail[0] : (e.detail?.step ?? e.detail);
                        if (step === 0) {
                            this.visible = false;
                            this.currentStep = 0;
                        } else {
                            this.visible = true;
                            if (step > this.currentStep) this.currentStep = step;
                        }
                    });
                },
                simulateProgress() {
                    const delays = [2000, 8000, 5000, 3000];
                    let total = 0;
                    delays.forEach((d, i) => {
                        total += d;
                        setTimeout(() => {
                            if (this.visible && this.currentStep <= i + 1)
                                this.currentStep = i + 2;
                        }, total);
                    });
                }
            }
        }
    </script>

</x-filament-panels::page>
